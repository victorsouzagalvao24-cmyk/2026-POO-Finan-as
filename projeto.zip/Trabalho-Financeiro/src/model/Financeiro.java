package model;

public class Financeiro {

    private String nome;
    private double salario;
    private double gastos;

    public Financeiro(String nome,
                      double salario,
                      double gastos) {

        this.nome = nome;
        this.salario = salario;
        this.gastos = gastos;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }

    public double getGastos() {
        return gastos;
    }

    public double getSaldo() {
        return salario - gastos;
    }

    public String getSituacao() {

        double saldo = getSaldo();

        if (saldo > 0) {

            return "Financeiramente estável";

        } else if (saldo == 0) {

            return "Sem sobra financeira";

        } else {

            return "Gastando mais do que ganha";
        }
    }
}