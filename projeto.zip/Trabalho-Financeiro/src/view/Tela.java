package view;

import model.Financeiro;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Tela extends JFrame {

    private JTextField txtNome, txtSalario, txtGastos;
    private JButton btnCalcular, btnExcluir, btnLimpar;
    private JLabel lblSituacao, lblSaldo;
    private JTextArea areaHistorico;
    private JPanel painelGrafico;

    private Financeiro financeiro;

    private ArrayList<String> historico = new ArrayList<>();

    public Tela() {

        setTitle("Controle Financeiro");
        setSize(1100, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        getContentPane().setBackground(new Color(230,230,230));

        // TÍTULO
        JLabel titulo = new JLabel("CONTROLE DE FINANÇAS");
        titulo.setFont(new Font("Arial", Font.BOLD, 34));
        titulo.setBounds(300,20,500,40);
        add(titulo);

        // ================= DADOS =================

        JPanel painelDados = criarPainel(60,100,500,220);
        add(painelDados);

        JLabel lblDados = new JLabel("DADOS DO CLIENTE");
        lblDados.setFont(new Font("Arial",Font.BOLD,22));
        lblDados.setBounds(120,15,300,30);
        painelDados.add(lblDados);

        painelDados.add(criarLabel("Nome:",40,70));
        painelDados.add(criarLabel("Salário:",40,120));
        painelDados.add(criarLabel("Gastos:",40,170));

        txtNome = criarCampo(140,70);
        txtSalario = criarCampo(140,120);
        txtGastos = criarCampo(140,170);

        painelDados.add(txtNome);
        painelDados.add(txtSalario);
        painelDados.add(txtGastos);

        // ================= RESULTADO =================

        JPanel painelResultado = criarPainel(60,350,500,130);
        add(painelResultado);

        btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(180,15,140,40);
        painelResultado.add(btnCalcular);

        lblSituacao = new JLabel("",SwingConstants.CENTER);
        lblSituacao.setFont(new Font("Arial",Font.BOLD,18));
        lblSituacao.setBounds(20,65,460,25);

        lblSaldo = new JLabel("",SwingConstants.CENTER);
        lblSaldo.setFont(new Font("Arial",Font.BOLD,20));
        lblSaldo.setBounds(20,90,460,30);

        painelResultado.add(lblSituacao);
        painelResultado.add(lblSaldo);

        // ================= GRÁFICO =================

        painelGrafico = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                desenharGrafico(g);
            }
        };

        painelGrafico.setBounds(60,510,500,170);
        painelGrafico.setBackground(Color.WHITE);
        painelGrafico.setBorder(BorderFactory.createLineBorder(Color.GRAY,2));

        add(painelGrafico);

        // ================= HISTÓRICO =================

        JPanel painelHistorico = criarPainel(620,100,400,580);
        add(painelHistorico);

        JLabel lblHistorico = new JLabel("HISTÓRICO");
        lblHistorico.setFont(new Font("Arial",Font.BOLD,24));
        lblHistorico.setBounds(120,20,200,30);

        painelHistorico.add(lblHistorico);

        areaHistorico = new JTextArea();
        areaHistorico.setEditable(false);
        areaHistorico.setFont(new Font("Monospaced",Font.PLAIN,14));

        JScrollPane scroll = new JScrollPane(areaHistorico);
        scroll.setBounds(20,70,360,400);

        painelHistorico.add(scroll);

        // BOTÕES HISTÓRICO

        btnExcluir = new JButton("Excluir Último");
        btnExcluir.setBounds(30,500,150,35);

        btnLimpar = new JButton("Limpar Tudo");
        btnLimpar.setBounds(210,500,150,35);

        painelHistorico.add(btnExcluir);
        painelHistorico.add(btnLimpar);

        // EVENTOS

        btnCalcular.addActionListener(e -> calcular());

        btnExcluir.addActionListener(e -> excluirUltimo());

        btnLimpar.addActionListener(e -> limparHistorico());

        setVisible(true);
    }

    // ================= MÉTODOS =================

    private JPanel criarPainel(int x,int y,int w,int h){

        JPanel p = new JPanel(null);

        p.setBounds(x,y,w,h);

        p.setBackground(Color.WHITE);

        p.setBorder(BorderFactory.createLineBorder(Color.GRAY,2));

        return p;
    }

    private JLabel criarLabel(String texto,int x,int y){

        JLabel l = new JLabel(texto);

        l.setFont(new Font("Arial",Font.BOLD,15));

        l.setBounds(x,y,100,30);

        return l;
    }

    private JTextField criarCampo(int x,int y){

        JTextField t = new JTextField();

        t.setBounds(x,y,300,35);

        return t;
    }

    private void calcular() {

        try {

            String nome = txtNome.getText();

            double salario = Double.parseDouble(txtSalario.getText());

            double gastos = Double.parseDouble(txtGastos.getText());

            financeiro = new Financeiro(nome,salario,gastos);

            lblSituacao.setText(nome + " - " + financeiro.getSituacao());

            lblSaldo.setText(
                    "Saldo restante: R$ "
                    + String.format("%.2f",financeiro.getSaldo())
            );

            historico.add(
                    "Nome: " + nome
                    + "\nSalário: R$ " + salario
                    + "\nGastos: R$ " + gastos
                    + "\nSaldo: R$ "
                    + String.format("%.2f",financeiro.getSaldo())
                    + "\n----------------------\n"
            );

            atualizarHistorico();

            painelGrafico.repaint();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Digite valores válidos!"
            );
        }
    }

    private void atualizarHistorico(){

        areaHistorico.setText("");

        for(String item : historico){

            areaHistorico.append(item);
        }
    }

    private void excluirUltimo(){

        if(!historico.isEmpty()){

            historico.remove(historico.size() - 1);

            atualizarHistorico();
        }
    }

    private void limparHistorico(){

        historico.clear();

        atualizarHistorico();
    }

    private void desenharGrafico(Graphics g){

        if(financeiro == null) return;

        double salario = financeiro.getSalario();
        double gastos = financeiro.getGastos();

        int largura = painelGrafico.getWidth();
        int altura = painelGrafico.getHeight();

        int alturaMax = 100;

        double maior = Math.max(salario,gastos);

        int hSalario = (int)((salario/maior)*alturaMax);
        int hGastos = (int)((gastos/maior)*alturaMax);

        int baseY = altura - 40;

        // SALÁRIO
        g.setColor(new Color(0,180,0));

        g.fillRect(
                largura/2 - 150,
                baseY - hSalario,
                80,
                hSalario
        );

        g.setColor(Color.BLACK);

        g.drawString(
                "R$ " + salario,
                largura/2 - 155,
                baseY - hSalario - 10
        );

        g.drawString(
                "Salário",
                largura/2 - 140,
                baseY + 20
        );

        // GASTOS
        g.setColor(Color.RED);

        g.fillRect(
                largura/2 + 70,
                baseY - hGastos,
                80,
                hGastos
        );

        g.setColor(Color.BLACK);

        g.drawString(
                "R$ " + gastos,
                largura/2 + 65,
                baseY - hGastos - 10
        );

        g.drawString(
                "Gastos",
                largura/2 + 85,
                baseY + 20
        );
    }
}